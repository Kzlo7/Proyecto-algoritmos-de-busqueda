from tkinter import *
import tkinter
from tkinter import ttk
import pandas as pd
import operator
from os import dup2, fdopen, path, terminal_size
import tkinter
from tkinter.constants import CENTER, COMMAND, Y
from typing import Text
from numpy.lib.shape_base import tile
import pandas as pd
import tkinter as tk
from tkinter import Grid, Image, Label, Misc, PhotoImage, ttk
import operator

###########################################
l1=pd.read_excel("kk.xlsx")

asd1=l1.columns.array

xx=[]#Nombre de las estaciones


for j in asd1:
    j = j
    xx.append(j)

xx.pop(0)

grafo=[]#Grafo que contiene las distancias minimas
for k in xx:
    t1=l1[k]
    t2=[]
    for j in t1:
        t2.append(j)
    grafo.append(t2)
###########################################
def dij(graf, src,op2):
    d1=len(graf)
    d2=len(graf[0])
    infi=999999999
    dist=[float(infi)]*d1
    punt=[-1]*d1
    dist[src]=0
    cola=[]
    for i in range(d1):
        cola.append(i)
    while cola:
        min=float(infi)
        min_index=-1
        for i in range(len(dist)):
            if(dist[i]<min and i in cola):
                min=dist[i]
                min_index=i
        u=min_index
        cola.remove(u)
        for i in range(d2):
            if graf[u][i] and i in cola:
                if (dist[u] + graf[u][i]<dist[i]):
                    dist[i]=dist[u]+graf[u][i]
                    punt[i]=u
    ll=[]
    p=[]
    c1=[]
    def mostrarcamino(punt,j,xx):
        if(punt[j]==-1):
            ll.append(xx[j])
            return
        mostrarcamino(punt,punt[j],xx)
        ll.append(xx[j])   
    mostrarcamino(punt,op2,xx)
    ñ9=round(dist[op2],2)
    p.append(ñ9)
    c1.append(ll)
    c1.append(p)
    return c1
###############################################################
def principal():
    v=Tk()#Se define la ventana principal
    im=PhotoImage(file="press.png")
    im1=PhotoImage(file="tr.png")
    im2=PhotoImage(file="boton.png")
    im3=PhotoImage(file="boton1.png")
    im4=PhotoImage(file="UNO.png")
    im5=PhotoImage(file="unotres.png")
    #Elementos de la ventana
    v.title("Minimal Routes")
    v.geometry("1010x753")
    im=PhotoImage(file="press.png")
    fondo=Label(image=im,text="imagen 5.0 de fonde",bd=0)
    fondo.place(x = 0, y = 0, relwidth = 1, relheight = 1)
    #Ventana Traslados
    v2 = Toplevel(v)
    v2.geometry("392x568")
    fondo1=Label(v2,image=im1,text="imagen 5.0 de fonde",bd=0)
    fondo1.place(x = 0, y = 0, relwidth = 1, relheight = 1)
    v2.title("Traslados")
    ##############################################################################################
    def uno():
        if(b1.getboolean(s=TRUE)):
            #Elementos de la sub-ventana
            v3=Toplevel(v2)
            v3.geometry("863x404")
            v3.title("Traslado 1:1")
            fondo1=Label(v3,image=im4,text="imagen 5.0 de fonde",bd=0)
            fondo1.place(x = 0, y = 0, relwidth = 1, relheight = 1)
            f2=Label(v3,wraplength=250)
            f3=Label(v3)
            n = tk.StringVar()
            n2 = tk.StringVar()
            list = ttk.Combobox(v3, textvariable = n)
            list1 = ttk.Combobox(v3, textvariable = n2)
            list1["values"]=(xx)
            list['values'] = (xx)
            #Algortimo para obtener traslado 1:1
            ##Funcion para obtener inicio de la ruta en base a .get() de combobox
            def klk(xx):
                c1=0
                for i in range(0,len(xx)):
                    if(list.get()==xx[i]):
                        c1=i
                        break
                return c1
            ##Funcion para obtener inicio de la ruta en base a .get() de combobox
            def klk1(xx):
                c1=0
                for i in range(0,len(xx)):
                    if(list1.get()==xx[i]):
                        c1=i
                        break
                return c1
            ##Funcion para mostrar resultados al usuario
            def fff():
                mm=dij(grafo,klk(xx),klk1(xx))
                tt=str(mm[0])
                tt1=str(mm[1])
                f2["text"]="Los locales visitados son: "+tt
                f3["text"]="Con una distancia de: "+tt1+"KM"
                f2.place(x=521,y=230)
                f3.place(x=521,y=200)   
            b2=tkinter.Button(v3,text="Calcular ruta",command=lambda: fff())
            b2.place(x=554,y=95)
            list.place(x=521,y=28)
            list1.place(x=521,y=68)
            list.current()
            v3.mainloop()
    ############################################################################################      
    def dos():
        if(b2.getboolean(s=TRUE)):
            #Especificaciones de la sub-ventana
            v3=Toplevel(v2)
            v3.geometry("1063x552")
            v3.title("Traslado 1:3")
            fondo1=Label(v3,image=im5,text="imagen 5.0 de fonde",bd=0)
            fondo1.place(x = 0, y = 0, relwidth = 1, relheight = 1)
            n = tk.StringVar()
            list = ttk.Combobox(v3, textvariable = n)
            list["values"]=(xx)
            list.place(x=36,y=320)
            d1=Label(v3)#,anchor=CENTER)
            d2=Label(v3)#,anchor=CENTER)
            d3=Label(v3)#,anchor=CENTER)
            salida=tkinter.Button(v3,text="Salir",command=lambda: v3.destroy())
            salida.place(x=990,y=503)
            #Algortimo para resolver traslado 1:3
            def unotres(u):
                v=0
                for i in range(0,len(xx)):
                    if(u==xx[i]):
                        v=i
                return grafo[v]
            def tresp(ini):
                dic={}
                for i in range(0,len(ini)):
                    dic[i]=ini[i]
    
                dicor = sorted(dic.items(), key=operator.itemgetter(1))
                m1=dicor[1]
                m2=dicor[2]
                m3=dicor[3]
                return m1,m2,m3
        
            def p2(u):
                ini=unotres(u)
                cer=tresp(ini)
                li=[]
                for i in cer:
                    li.append(xx[i[0]])
                d1["text"]=str(xx[cer[0][0]])+"\n Distancia: "+str(cer[0][1])+"KM"
                d2["text"]=str(xx[cer[1][0]])+"\n Distancia: "+str(cer[1][1])+"KM"
                d3["text"]=str(xx[cer[2][0]])+"\n Distancia: "+str(cer[2][1])+"KM"
                d2.place(x=545,y=53)
                d1.place(x=372,y=428)
                d3.place(x=900,y=220)
                list["values"]=li   
            b3=tkinter.Button(v3,text="Calcular ruta",command=lambda: p2(list.get()))
            b3.place(x=69,y=350)
            v3.mainloop()
    b1=tkinter.Button(v2,image=im2,command=uno)
    b1.place(x=5,y=120)
    b2=tkinter.Button(v2,image=im3,command=dos)
    b2.place(x=175,y=485)
    v.mainloop()
###############################################################
#Se crea la ventana login
v0=Tk()
im0=PhotoImage(file="login.png")
im01=PhotoImage(file="ingresar.png")
im02=PhotoImage(file="contra.png")
v0.title("Login")
v0.geometry("347x619")
fondo0=Label(image=im0,text="imagen 5.0 de fonde",bd=0)
fondo0.place(x = 0, y = 0, relwidth = 1, relheight = 1)
usuario=StringVar()
usu=Entry(v0, width=15, textvariable=usuario).place(x=152,y=335)
contraseña=StringVar()
con=Entry(v0, width=15, textvariable=contraseña,show="*").place(x=152,y=388)
def pas():
    if(usuario.get()=="mauricio"and contraseña.get()=="hidalgo"):
        v0.destroy()
        principal()
    else:
        inco=Label(v0,text="Contraseña incorrecta").place(x=100,y=423)
bot=tkinter.Button(v0,image=im01,command=lambda: pas())
bot.place(x=74,y=450)
v0.mainloop()
